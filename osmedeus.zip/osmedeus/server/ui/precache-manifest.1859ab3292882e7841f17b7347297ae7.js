self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.c5541365.js"
  },
  {
    "revision": "9deb8aa3fa8a3f53bdaa",
    "url": "/static/js/main.f79c3c18.chunk.js"
  },
  {
    "revision": "6b040d45a57bdedb0a57",
    "url": "/static/js/2.ba701dbe.chunk.js"
  },
  {
    "revision": "9deb8aa3fa8a3f53bdaa",
    "url": "/static/css/main.1991d3c2.chunk.css"
  },
  {
    "revision": "53282c6fda3064d03b353a17d692dd8c",
    "url": "/index.html"
  }
];